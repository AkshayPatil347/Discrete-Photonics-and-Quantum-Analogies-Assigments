%--- Method 2: Trotter Decomposition
         
J=1;
omega=20*J;
z0=2*pi/omega;
n=50;
beta_0=0.0;


%K = omega*1;
%K = omega*2.4048;
K = omega*3.1;
J_eff=J*abs(besselj(0,K/omega));

    %%%%% quasi-energy spectrum
    Np=10000;
    Delz=z0/(10000-1);
    period = (0:Delz:z0);
    U=eye(51); 
    for c=1:1:Np-1
        beta=K*cos(omega*period(c));
        disp(period(c))
            for i=1:n
                H(i,i)=-beta_0 - (i)*beta;
                H(i,i+1)=-J_eff;
                H(i+1,i)=-J_eff;
            end
        U=expm(-1i*H*Delz)*U;
                    
    end 
    disp(U)
    disp(H)
for m=1:51  
    if m==(51+1)/2
    Ei(m)=1;
    else
    Ei(m)=0;
    end
end
Ei
     E_zi = U.*Ei;
     I=abs(E_zi).^2; % Intensity
     E_zi

     figure(1); set(gcf,'Position',[800 400 420 340]);

    plot(Delz, I(:, i), '-', 'Linewidth', 1.5, 'color', [0.9, 0.4, 0.4]); hold on;%%Red

    xlabel('Propagation distance (mm)'); ylabel('Normalized intensities, I_{i}');

    set(gca,'FontSize',14); set(gca,'linewidth',2)

 

    %%% image

    figure(2); set(gcf,'Position',[500 200 140 500])

    %imagesc(abs(E)); %

    imagesc(I); 

    colormap(hot); colorbar; axis off;

        
        








