%Q4a
J=1;
omega=20*J;
a=1;
% K varies from -6.28 for omega*z'=pi to infinity for omega*z'=(pi/2) but
% taking only range from 0 to 6 for this plot and equation for plot is
% analytically solved in Handwritten Answers.
K=omega*[0:0.005:6];

z0=2*pi/omega;

k=0:z0/1200:z0;
A = K/omega;


Epsi = 2*J*abs(besselj(0,A)).*cos(k*a);
B = Epsi/J;


plot(A,B);
axis([0 6 0 2]);

xlabel('K/{\Omega}')
ylabel('{\epsilon}/J')
title('Floquet Spectrum In Fourier/Reciprocal Space')
