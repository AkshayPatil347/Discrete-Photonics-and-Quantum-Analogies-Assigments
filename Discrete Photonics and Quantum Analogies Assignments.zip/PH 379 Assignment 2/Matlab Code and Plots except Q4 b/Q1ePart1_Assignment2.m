%Q1e Part 1 i.e Overlap in Q1c
clc; clear all; close all; 

 

beta=0; %%% Propagation constant same for all waveguides



J=0.1; %% per mm,  Coupling

L=100; %% mm,  Max length of the device 
n=63;





for i=1:62
    H(i,i)=-beta;% Diagonal Elements Of H
end
for m=2:3:62
    H(m,m+1)=-J;% Intraunit Cell Coupling
    H(m,m-1)=-J;% Intraunit Cell Coupling
    H(m-1,m)=-J;% Intraunit Cell Coupling
    H(m+1,m)=-J;% Intraunit Cell Coupling
end
for a=3:3:62
    H(a,a+2)=-J; % Interunit Cell Coupling of w-1 th and w th Unit Cell
    H(a+2,a)=-J; % Interunit Cell Coupling of w th and w-1 th Unit Cell
end
    
%-- Hamiltonian, eigen values and eigen states
    [V, D]=eig(H)

for i=1:63  
    if i==((63+1)/2)+1
    Ei(i)=1;
    else
    Ei(i)=0;
    end
end

Overlap = Ei*V







