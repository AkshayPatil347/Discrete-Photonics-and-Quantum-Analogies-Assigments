    
%Q2b

clc,clear
k=1;
n=50;
beta=0.0;;
J=0.1
for i=1:n
        H(i,i)=-beta + (i-1)*J/4;
        H(i,i+1)=-J;
        H(i+1,i)=-J;
end
disp (H)
x=0:0.02:1;
mu=0.5;
s=0.2;
p1 = -.5 * ((x - mu)/s) .^ 2;

Ei = exp(p1);
figure(4); set(gcf,'Position',[800 400 420 340]);
plot(x,Ei)
xlabel('x (m)'); ylabel('Intensity of Guassian Curve');

disp (Ei)
L=500

    Np=10000; %% number of points along z

    Zspan=linspace(0, L, Np);

    [z, E]=ode45(@(z, E)Propagator(z, E, H), Zspan, Ei); %%, option);

 

    I=abs(E).^2; % Intensity

   
    
    %%%-- plot intensity

    figure(1); set(gcf,'Position',[800 400 420 340]);
    for i=1:51
    plot(z, I(:, i), '-', 'Linewidth', 1.5, 'color', [0.004*i, 0.001*i, 0.002*i]); hold on;%%Red

    end
    xlabel('Propagation distance (mm)'); ylabel('Normalized intensities, I_{i}');

    set(gca,'FontSize',14); set(gca,'linewidth',2)

     figure(3); set(gcf,'Position',[800 400 420 340]);

    plot(z, I(:, 26), '-', 'Linewidth', 1.5, 'color', [0.004*i, 0.001*i, 0.002*i]); hold on;%%Red

   
    xlabel('Propagation distance (mm)'); ylabel('Normalized intensities, I_{26}');

    set(gca,'FontSize',14); set(gca,'linewidth',2)

 

    %%% image

    figure(2); set(gcf,'Position',[500 200 140 500])

    %imagesc(abs(E)); %

    imagesc(I); 

    colormap(hot); colorbar; axis off;
    


   
function dEdz=Propagator(z, E, H)

        dEdz=(-1i)*H*E;

    end