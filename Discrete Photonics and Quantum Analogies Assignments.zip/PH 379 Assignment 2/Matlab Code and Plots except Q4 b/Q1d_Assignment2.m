%Q1d

 

function coupler

clc; clear all; close all; 

 

beta=0; %%% Propagation constant same for all waveguides



J=0.1; %% per mm,  Coupling

L=100; %% mm,  Max length of the device 
n=62;





for i=1:62
    H(i,i)=-beta;% Diagonal Elements Of H
end
for m=2:3:62
    H(m,m+1)=-J;% Intraunit Cell Coupling
    H(m,m-1)=-J;% Intraunit Cell Coupling
    H(m-1,m)=-J;% Intraunit Cell Coupling
    H(m+1,m)=-J;% Intraunit Cell Coupling
end
for a=3:3:60
    H(a,a+2)=-J; % Interunit Cell Coupling of w-1 th and w th Unit Cell
    H(a+2,a)=-J; % Interunit Cell Coupling of w th and w-1 th Unit Cell
end
    H
%-- Hamiltonian, eigen values and eigen states
    [V, D, F]=eig(H);

 

%%% Dynamics %%%%

    %-- input state
for i=1:63  
    if i==31
    Ei(i)=1;
    elseif i==33
    Ei(i)=-1;
    elseif i==34
    Ei(i)=1;
    else
    Ei(i)=0;
    end
end

    Np=400; %% number of points along z

    Zspan=linspace(0, L, Np);

    [z, E]=ode45(@(z, E)Propagator(z, E, H), Zspan, Ei); %%, option);

 

    I=abs(E).^2; % Intensity

    %%%-- plot intensity

    figure(1); set(gcf,'Position',[800 400 420 340]);

    plot(z, I(:, 31), '-', 'Linewidth', 1.5, 'color', [0.9, 0.4, 0.4]); hold on;%%Red
    
    plot(z, I(:, 33), '--', 'Linewidth', 1.5, 'color', [0.4, 0, 0.9]); hold on;%%Violet

    plot(z, I(:, 34), '--', 'Linewidth', 1.5, 'color', [0.3, 0, 0.3]); hold on;%%Brown

    xlabel('Propagation distance (mm)'); ylabel('Normalized intensities, I_{31,33,34}');

    set(gca,'FontSize',14); set(gca,'linewidth',2)

 

    %%% image

    figure(2); set(gcf,'Position',[500 200 140 500])

    %imagesc(abs(E)); %

    imagesc(I); 

    colormap(hot); colorbar; axis off;

    

    function dEdz=Propagator(z, E, H)

        dEdz=(-1i)*H*E;

    end

end

