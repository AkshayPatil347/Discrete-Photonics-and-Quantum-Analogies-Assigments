% Q3 b Case 2 = J_2 > J_1

clc,clear

n=400;
beta=0.0;;
J_1 = 1;
J_2 = 2;
for i=1:n
    H(i,i)=-beta;% Diagonal Elements Of H
end
for m=2:2:n
    H(m,m+1)=-J_1;% Interunit Cell Coupling
    H(m,m-1)=-J_2;% Intraunit Cell Coupling
    H(m-1,m)=-J_2;% Intraunit Cell Coupling
    H(m+1,m)=-J_1;% Interunit Cell Coupling
end



disp (H)
      

x=1:1:401;
y = eig(H) % Column Vector Of Energy Eigen Values



plot(x,y) 
xlabel('Real Space with d i.e bond length = 1 for x= 0 to x= 400 units')
ylabel('Energy Eigen Values')
title('Energy Spectrum In Real Space for J_2 > J_1 ')
legend('Energy Spectrum of waveguides A and B for 200 Unit Cells in Real Space')