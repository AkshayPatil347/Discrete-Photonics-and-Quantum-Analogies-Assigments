% Q3 b Case 2 = J_1 < J_2
clc; clear all; close all; 
beta = 0;
d=1;


%Case 1 = J_1 > J_2
%J_1 = 2; 
%J_2 = 1;

%Case 2 = J_2 > J_1
J_1 = 1; 
J_2 = 5;

%Case 3 = J_2 = J_1
%J_1 = 1; 
%J_2 = 1;
k = -3.14:0.01:3.14


E_1 = -beta + ((J_1)^2+(J_2)^2+2*(J_1)*(J_2)*2*cos(k*d)).^0.5

E_2 = -beta - ((J_1)^2+(J_2)^2+2*(J_1)*(J_2)*2*cos(k*d)).^0.5

plot(k,E_1);hold on;
plot(k,E_2);hold off;

xlabel('kd')
ylabel('Energy Eigen Values in Fourier Space')
title('Energy Spectrum In Fourier Space for J_1<J_2 - Band Gap Opens')
legend('Energy Spectrum E_1 vs kd ',...
    'Energy Spectrum E_2 vs kd')