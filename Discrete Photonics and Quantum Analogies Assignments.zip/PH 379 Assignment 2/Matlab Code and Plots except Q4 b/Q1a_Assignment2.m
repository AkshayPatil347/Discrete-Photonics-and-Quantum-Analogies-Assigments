%Q1a

clc,clear
n=62;
beta=0.0;
J=0.1;



for i=1:62
    H(i,i)=-beta;% Diagonal Elements Of H
end
for m=2:3:62
    H(m,m+1)=-J;% Intraunit Cell Coupling
    H(m,m-1)=-J;% Intraunit Cell Coupling
    H(m-1,m)=-J;% Intraunit Cell Coupling
    H(m+1,m)=-J;% Intraunit Cell Coupling
end
for a=3:3:60
    H(a,a+2)=-J; % Interunit Cell Coupling of w-1 th and w th Unit Cell
    H(a+2,a)=-J; % Interunit Cell Coupling of w th and w-1 th Unit Cell
end
      

x1=1:1:42;
x2=1:2:43;
y = eig(H) % Column Vector Of Energy Eigen Values
y(1:3:62)=[] % Removes the eigen values of waveguide a

z = eig(H)
z(2:3:62)=[] % Removes the eigen values of waveguide b
z(2:2:41)=[] % Removes the eigen values of waveguide c to get column of only waveguide a energy eigen values.
plot(x1,y) 
hold on
plot(x2,z) 
hold off
xlabel('Real Space with d i.e bond length = 1 for x= 0 to x= 41 units')
ylabel('Energy Eigen Values')
title('Energy Spectrum In Real Space')
legend('Energy Spectrum of waveguides b and c for 21 Unit Cells in Real Space',...
    'Energy Spectrum of waveguide a for 21 Unit Cells in Real Space')

